package com.ribhlab.ribhmeasure;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.view.View;

public final class MainActivity extends BaseActivity {
    @Override public void onCreate(Bundle b){super.onCreate(b);Ads.setup(this);render();}
    void render(){
        LinearLayout root=Ui.vertical(this);root.setBackgroundColor(Ui.BG);
        LinearLayout body=Ui.column(this,R.string.app_name);
        TextView tagline=Ui.text(this,getString(R.string.tagline),22,Ui.TEAL,true);body.addView(tagline);
        Ui.gap(this,body,3);body.addView(Ui.text(this,getString(R.string.home_subtitle),13,Ui.SUB,false));
        Ui.gap(this,body,21);
        item(body,"⌖",R.string.gps_area,R.string.gps_area_desc,()->gps(true));
        item(body,"⇢",R.string.gps_distance,R.string.gps_distance_desc,()->gps(false));
        item(body,"▣",R.string.camera_measure,R.string.camera_measure_desc,()->open(CameraMeasureActivity.class));
        item(body,"┠",R.string.ruler,R.string.ruler_desc,()->open(RulerActivity.class));
        item(body,"◉",R.string.level,R.string.level_desc,()->open(LevelActivity.class));
        Ui.gap(this,body,10);
        item(body,"▤",R.string.history,R.string.history,()->open(HistoryActivity.class));
        item(body,"⚙",R.string.settings,R.string.settings,()->open(SettingsActivity.class));
        if(BuildConfig.DEMO_ADS){Ui.gap(this,body,8);body.addView(Ui.text(this,getString(R.string.ads_demo),12,Ui.GOLD,false));}
        ScrollView scroll=Ui.scroll(this,body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        addBanner(root);setContentView(root);
    }
    private void item(LinearLayout parent,String ico,int title,int desc,Runnable action){
        LinearLayout card=Ui.card(this); LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);
        TextView symbol=Ui.text(this,ico,29,Ui.TEAL,true); symbol.setGravity(android.view.Gravity.CENTER);
        line.addView(symbol,new LinearLayout.LayoutParams(Ui.dp(this,45),Ui.dp(this,57)));
        LinearLayout labels=Ui.vertical(this);labels.addView(Ui.text(this,getString(title),17,Ui.TEXT,true));
        if(desc!=title)labels.addView(Ui.text(this,getString(desc),12,Ui.SUB,false));
        line.addView(labels,new LinearLayout.LayoutParams(0,-2,1));card.addView(line);
        card.setOnClickListener(v->action.run());
        parent.addView(card,Ui.lp(this,-2));Ui.gap(this,parent,11);
    }
    private void gps(boolean area){Intent i=new Intent(this,GpsMeasureActivity.class);i.putExtra("area",area);startActivity(i);}
    private void open(Class<?> c){startActivity(new Intent(this,c));}
    @Override protected void onResume(){super.onResume();Ads.initializeIfAllowed(this);}
}
